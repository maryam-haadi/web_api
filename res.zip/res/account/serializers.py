from rest_framework import routers, serializers, viewsets
from django.contrib.auth.models import User
from.models import Profile



class Register_serializers(serializers.ModelSerializer):

    class Meta:
        model=User
        fields=['username','password','email']



class Profile_serializers(serializers.ModelSerializer):

    class Meta:
        model=Profile
        fields=['user','image']





















